﻿namespace BatchMailer
{
    public class Recipient
    {
        public string FirstName { get; set; } = "";
        public string LastName { get; set; } = "";
        public string Email { get; set; } = "";
        public string Attachment1 { get; set; } = "";
        public string Attachment2 { get; set; } = "";
    }
}
